<?php
function company_brand_func( $atts, $content = null ) { // New function parameter $content is added!
	extract( shortcode_atts( array(
			'image_logo_slider' => '',
			'color' => '#FFF',
			'text_content' => '',
	), $atts ) );
	
	$logo_slider_url = wp_get_attachment_image_src(  $image_logo_slider , 'full' )[0];
	
	$content = wpb_js_remove_wpautop($content, true); // fix unclosed/unwanted paragraph tags in $content, this is textarea on elements
	
	$brands = get_option('supplier_following_brands'); 
	
	$html = '<svg id="svg" viewbox="0 0 100 100">
			  <circle cx="50" cy="50" r="45" fill="#FDB900"/>
			  <path fill="none" stroke-linecap="round" stroke-width="5" stroke="#fff"
			        stroke-dasharray="2.212,251.2"
			        d="M50 10
			           a 40 40 0 0 1 0 80
			           a 40 40 0 0 1 0 -80"/>
			  <text x="50" y="50" text-anchor="middle" dy="7" font-size="20">1%</text>
			</svg>';
	
	return $html;
}
add_shortcode( 'company_brand', 'company_brand_func' );


