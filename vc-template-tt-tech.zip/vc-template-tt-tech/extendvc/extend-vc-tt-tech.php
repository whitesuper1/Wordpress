<?php
add_action( 'vc_before_init', 'vc_template_integrateWithVC' );
function vc_template_integrateWithVC() {
	vc_map( array(
			"name" => __( "Company Brand", "vc-template-tt-tech" ),
			"base" => "company_brand",
			"class" => "",
			"category" => __( "Content", "vc-template-tt-tech"),
			'admin_enqueue_js' => array(plugin_dir_path().'/vc_extend/bartag.js'),
			'admin_enqueue_css' => array(plugin_dir_path().'/vc_extend/bartag.css'),
			"params" => array(
					array(
							"type" => "textarea_html",
							"holder" => "",
							"class" => "",
							"heading" => __( "Title", "vc-template-tt-tech" ),
							"param_name" => "content",
							"value" => __( "", "vc-template-tt-tech" ),
							"description" => __( "Description for foo param.", "vc-template-tt-tech" )
							
					),
					array(
							"type" => "attach_image",
							"holder" => "",
							"class" => "",
							"heading" => __( "Logo Slider", "vc-template-tt-tech" ),
							"param_name" => "image_logo_slider",
							"value" => __( "", "vc-template-tt-tech" ),
							"description" => __( "Description for foo param.", "vc-template-tt-tech" )
					),
					array(
							"type" => "colorpicker",
							"class" => "",
							"heading" => __( "Text color", "vc-template-tt-tech" ),
							"param_name" => "color",
							"value" => '#FF0000', //Default Red color
							"description" => __( "Choose text color", "vc-template-tt-tech" )
					),
					array(
							"type" => "textarea",
							"holder" => "div",
							"class" => "",
							"heading" => __( "Content", "vc-template-tt-tech" ),
							"param_name" => "text_content", // Important: Only one textarea_html param per content element allowed and it should have "content" as a "param_name"
							"value" => __( "<p>I am test text block. Click edit button to change this text.</p>", "vc-template-tt-tech" ),
							"description" => __( "Enter your content.", "vc-template-tt-tech" )
					)
			)
	) );
	
	vc_map( array(
			"name" => __( "Company Opening Times", "vc-template-tt-tech" ),
			"base" => "company_open_times",
			"class" => "",
			"category" => __( "Content", "vc-template-tt-tech"),
			'admin_enqueue_js' => array(plugin_dir_path().'/vc_extend/bartag.js'),
			'admin_enqueue_css' => array(plugin_dir_path().'/vc_extend/bartag.css'),
			"params" => array(
					array(
							"type" => "attach_image",
							"class" => "",
							"heading" => __( "Image Event", "vc-template-tt-tech" ),
							"param_name" => "image_event",
							"value" => '',
							"description" => __( "Image of Event.", "vc-template-tt-tech" )
					),
					array(
							"type" => "textfield",
							"class" => "",
							"heading" => __( "Url", "vc-template-tt-tech" ),
							"param_name" => "image_link",
							"value" => '',
							"description" => __( "Redirect when click image.", "vc-template-tt-tech" )
					),
					array(
							"type" => "checkbox",
							"class" => "",
							"heading" => __( "Show Image", "vc-template-tt-tech" ),
							"param_name" => "image_event_show",
							"value" => array(__('yes',"vc-template-tt-tech") => 'yes'), //Default Red color
							"description" => __( "Allow Show Image", "vc-template-tt-tech" )
					),
			)
	) );
	
}