<?php 

function vc_template_tt_tech_scripts() {
	
	wp_enqueue_script( 'custom-logo-social-link',plugin_dir_url(dirname(__FILE__)). 'js/custom-js-tt-tech.php' , array(), '1.0.0', true );
}

add_action( 'wp_enqueue_scripts', 'vc_template_tt_tech_scripts' );
?>


