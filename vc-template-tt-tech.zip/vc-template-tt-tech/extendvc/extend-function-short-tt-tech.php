<?php 
global $current_class;
$current_class = 'zig-zac';
function oddeven_post_class ( $classes ) {
	global $current_class;
	$classes[] = $current_class;
	$current_class = ($current_class != 'odd') ? 'odd' : 'zig-zac';
	return $classes;
}
add_filter ( 'post_class' , 'oddeven_post_class' );