<?php
/*
Plugin Name: VC Template TT-Tech
Plugin URI: http://www.tt-tech.de/
Description: Create Elements with visual composer
Text Domain: vc-template-tt-tech
Domain Path: /languages
Version: 1.0.1
Author: LeTin
*/
/*
 * Version: 1.0.1 Change Logs
 * Create Elements with visual composer
 */
define( 'VC_TEMPLATE_TT_TECH_PLUGIN_DIR', plugin_dir_path( __FILE__ ) ); //Dinh nghia duong dan cho plugin;

//shortfunction
require_once ( VC_TEMPLATE_TT_TECH_PLUGIN_DIR . 'extendvc/extend-function-short-tt-tech.php');
//visual composer
require_once ( VC_TEMPLATE_TT_TECH_PLUGIN_DIR . 'extendvc/extend-vc-tt-tech.php');
require_once ( VC_TEMPLATE_TT_TECH_PLUGIN_DIR . 'vc_templates/template-tt-tech.php');

//js api
require_once ( VC_TEMPLATE_TT_TECH_PLUGIN_DIR . 'extendvc/extend-js-php-tt-tech.php');

function vc_template_init() {
 $plugin_dir = basename(dirname(__FILE__)) ."/languages";
 load_plugin_textdomain( 'vc-template-tt-tech', false, $plugin_dir );
}
add_action('plugins_loaded', 'vc_template_init');
