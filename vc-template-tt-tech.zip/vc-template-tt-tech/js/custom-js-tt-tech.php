<?php
$root = dirname(dirname(dirname(dirname(dirname(__FILE__)))));
if ( file_exists( $root.'/wp-load.php' ) ) {
    require_once( $root.'/wp-load.php' );
//    require_once( $root.'/wp-config.php' );
} 
if ( file_exists( $root.'/htdocs/wp-load.php' ) ) {
	require_once( $root.'/htdocs/wp-load.php' );
	//    require_once( $root.'/wp-config.php' );
}
else {
	$root = dirname(dirname(dirname(dirname(dirname(dirname(__FILE__))))));
	if ( file_exists( $root.'/wp-load.php' ) ) {
    require_once( $root.'/wp-load.php' );
//    require_once( $root.'/wp-config.php' );
	}
	if ( file_exists( $root.'/htdocs/wp-load.php' ) ) {
		require_once( $root.'/htdocs/wp-load.php' );
		//    require_once( $root.'/wp-config.php' );
	}
}

header('Content-type: application/x-javascript');
?>
<?php if(!is_admin()) {?>
jQuery(document).ready(function() {
	var logo_header = "<?php echo get_option('logo-img-url');?>";
	var social_facebook_url = "<?php echo get_option('supplier_social_f'); ?>";
	var social_twitter_url = "<?php echo get_option('supplier_social_t'); ?>";
	var social_google_plus_url = "<?php echo get_option('supplier_social_g'); ?>";
	var social_instagram_url = "<?php echo get_option('supplier_social_instagram'); ?>";
	var social_spotcity_url = "<?php echo get_option('supplier_social_spot'); ?>";
	if(logo_header.length !=0){
		jQuery('img.normal').attr('src',logo_header);
		jQuery('.logo-footer img').attr('src',logo_header);
	}
	if(social_facebook_url.length !=0){
		jQuery('.social-facebook a').attr('href',social_facebook_url);
		jQuery('.q_social_icon_holder .fa.fa-facebook').parent().parent().attr('href',social_facebook_url);
	}
	if(social_twitter_url.length !=0){
		jQuery('.q_social_icon_holder .fa.fa-twitter').parent().parent().attr('href',social_twitter_url);
	}
	if(social_google_plus_url.length !=0){
		jQuery('.q_social_icon_holder .fa.fa-google-plus').parent().parent().attr('href',social_google_plus_url);
	}
	if(social_instagram_url.length !=0){
		jQuery('.q_social_icon_holder .fa.fa-instagram').parent().parent().attr('href',social_instagram_url);
	}
	if(social_spotcity_url.length !=0){
		jQuery('.social-spotcity a').attr('href',social_spotcity_url);
		jQuery('.q_social_icon_holder .fa.fa-spotcity').parent().parent().attr('href',social_spotcity_url);
	}
	
});
<?php }?>
